﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tester
{
    class Tester
    {
        static void Main(String[] args)
        {
            FutureHolder_tester.Run();
            //Cache_tester.Run();
            //RendezvousPort_Tester.Test1();
            //RendezvousPort_Tester.Test2();
        }
    }
}
